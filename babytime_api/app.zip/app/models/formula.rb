class Formula < ApplicationRecord
  belongs_to :activity
end
