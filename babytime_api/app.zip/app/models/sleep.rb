class Sleep < ApplicationRecord
  belongs_to :activity
  
end
