class Diaper < ApplicationRecord
  belongs_to :activity
end
