function WelcomePage(){
return (
   <div class="welcomeBack" style={{width: "100vw", height: "100vh", textAlign:"center"}}>
<div style={{width: '50%', float: "right",marginTop:"30vh", padding:"10px"}}>
<h1>Welcome to BABYTIME!</h1>
<p><small>Parenting is hard. First-time parenting is harder. That’s why BabyTime was made.
Record, track, and analyze your baby’s activities and find the exact answers that you’re looking for.
Take your first step into parenting with Babytime to always stay on top of the parenting game.</small></p>
</div>
   </div>

)

}

export default WelcomePage
